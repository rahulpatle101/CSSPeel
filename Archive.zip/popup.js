document.addEventListener("DOMContentLoaded", () => {
  const tabButtons = document.querySelectorAll(".tab-btn");
  const tabPanels = document.querySelectorAll(".tab-panel");

  tabButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      tabButtons.forEach(b => b.classList.remove("active"));
      tabPanels.forEach(p => p.classList.remove("active"));

      btn.classList.add("active");
      document.getElementById(btn.dataset.tab).classList.add("active");
    });
  });

  // 🔁 Extract button injection
  document.getElementById("extract").addEventListener("click", async () => {
    console.log("🧪 Extract button clicked");
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["tokenExtractor.js"]
    }, () => {
      console.log("✅ tokenExtractor.js injected into tab", tab.id);
    });
  });

  // 🧭 Load and render stored tokens
  chrome.storage.local.get("designTokens", (res) => {
    const tokens = res.designTokens || {};
    console.log("📦 Tokens loaded in popup:", tokens);

    renderColors(tokens.colors || []);
    renderTypography(tokens);
    renderSpacing(tokens.spacings || {});
    renderBorders(tokens.radii || {});
    renderShadows(tokens.shadows || []);
  });

  function createTokenItem(name, preview, value) {
    const div = document.createElement("div");
    div.className = "token";

    const prev = document.createElement("div");
    prev.className = "preview";
    if (preview) prev.style.background = preview;

    const val = document.createElement("div");
    val.className = "value";
    val.innerText = name;

    const copy = document.createElement("div");
    copy.className = "copy";
    copy.innerText = "Copy";
    copy.addEventListener("click", () => {
      navigator.clipboard.writeText(value || name);
      copy.innerText = "Copied!";
      setTimeout(() => (copy.innerText = "Copy"), 1000);
    });

    div.appendChild(prev);
    div.appendChild(val);
    div.appendChild(copy);
    return div;
  }

  function renderColors(colors) {
    const container = document.getElementById("colors");
    container.innerHTML = "";
    colors.forEach(color => {
      container.appendChild(createTokenItem(color, color, color));
    });
  }

  function renderTypography(tokens) {
    const container = document.getElementById("typography");
    container.innerHTML = "";
    if (tokens.fontFamilies) {
      tokens.fontFamilies.forEach(f => {
        const el = createTokenItem(f, null, f);
        el.querySelector(".value").style.fontFamily = f;
        container.appendChild(el);
      });
    }

    if (tokens.fontSizes) {
      Object.entries(tokens.fontSizes).forEach(([key, val]) => {
        const el = createTokenItem(`${key}`, null, `${val}px`);
        el.querySelector(".value").style.fontSize = `${val}px`;
        container.appendChild(el);
      });
    }
  }

  function renderSpacing(spacings) {
    const container = document.getElementById("spacing");
    container.innerHTML = "";
    Object.entries(spacings).forEach(([key, val]) => {
      container.appendChild(createTokenItem(`${key}`, null, `${val}px`));
    });
  }

  function renderBorders(radii) {
    const container = document.getElementById("borders");
    container.innerHTML = "";
    Object.entries(radii).forEach(([key, val]) => {
      container.appendChild(createTokenItem(`${key}`, null, `${val}px`));
    });
  }

  function renderShadows(shadows) {
    const container = document.getElementById("shadows");
    container.innerHTML = "";
    shadows.forEach(shadow => {
      const el = createTokenItem(shadow, null, shadow);
      el.querySelector(".preview").style.boxShadow = shadow;
      container.appendChild(el);
    });
  }

  // Export buttons
  document.getElementById("export-css").addEventListener("click", () => {
    chrome.storage.local.get("designTokens", (res) => {
      const tokens = res.designTokens || {};
      let css = `:root {\n`;

      (tokens.colors || []).forEach((c, i) => css += `  --color-${i + 1}: ${c};\n`);
      if (tokens.fontFamilies) css += `  --font-body: ${tokens.fontFamilies[0]};\n`;
      if (tokens.fontSizes) Object.entries(tokens.fontSizes).forEach(([k, v]) => css += `  --${k}: ${v}px;\n`);
      if (tokens.spacings) Object.entries(tokens.spacings).forEach(([k, v]) => css += `  --${k}: ${v}px;\n`);
      if (tokens.radii) Object.entries(tokens.radii).forEach(([k, v]) => css += `  --${k}: ${v}px;\n`);
      if (tokens.shadows) tokens.shadows.forEach((s, i) => css += `  --shadow-${i + 1}: ${s};\n`);

      css += `}\n`;

      downloadFile("tokens.css", css);
    });
  });

  document.getElementById("export-json").addEventListener("click", () => {
    chrome.storage.local.get("designTokens", (res) => {
      const blob = new Blob([JSON.stringify(res.designTokens, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      downloadFile("tokens.json", url, true);
    });
  });

  function downloadFile(filename, content, isUrl = false) {
    const a = document.createElement("a");
    a.href = isUrl ? content : URL.createObjectURL(new Blob([content], { type: "text/plain" }));
    a.download = filename;
    a.click();
  }

  // Open full-page viewer
  document.getElementById("open-viewer").addEventListener("click", () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("viewer.html") });
  });
});